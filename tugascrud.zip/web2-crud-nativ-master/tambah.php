<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data</title>
</head>
<body>
<a href="index.php">Kembali</a>
    <br/><br/>
<button sty></button>
    <form action="tambah.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td style="color: red; text-align: center;">Name</td>
                <td><input type="text" name="name" required oninvalid="this.setCustomValidity('isi data nama')" oninput="setCustomValidity('')"></td>
            </tr>
            <tr> 
                <td>Email</td>
                <td><input type="text" name="email" required oninvalid="this.setCustomValidity('isi data email')" oninput="setCustomValidity('')"></td>
            </tr>
            <tr> 
                <td>Username</td>
                <td><input type="text" name="username" required oninvalid="this.setCustomValidity('isi data Username')" oninput="setCustomValidity('')"></td>
            </tr>
            <tr> 
                <td>Password</td>
                <td><input type="text" name="password" required oninvalid="this.setCustomValidity('isi data Password')" oninput="setCustomValidity('')"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>

    <?php

    //pengondisian untuk menjalankan perintah tambah data.
    if(isset($_POST['Submit'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $usrname = $_POST['username'];
        $pwd = $_POST['password'];
            // import koneksi
            include_once("config.php");
            // query tmmbah data
            $result = mysqli_query($mysqli, "INSERT INTO user(nama,email,username,password) VALUES('$name','$email','$usrname','$pwd')");

            // pemberitahuan sukses menambah data
            echo "Data berhasil ditambah. <a href='index.php'>Lihat data</a>";
        
    }
    ?>
</body>
</html>