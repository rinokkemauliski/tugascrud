<?php
// membuat koneksi

$host = "localhost";
$db_name = "crud-nativ";
$username = "root";
$password = "";

$mysqli = mysqli_connect($host, $username, $password, $db_name);
?>